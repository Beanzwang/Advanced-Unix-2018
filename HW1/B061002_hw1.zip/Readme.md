# Compile
```
make # output ./hw1
```

# Test
```
telnet localhost [port]
```
